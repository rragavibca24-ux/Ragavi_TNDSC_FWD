// Add event listener to navigation links

document.querySelectorAll('header nav a').forEach(link => {

    link.addEventListener('click', event => {

        event.preventDefault();

        const sectionId = link.getAttribute('href');

        document.querySelector(sectionId).scrollIntoView({ behavior: 'smooth' });

    });

});

// Add animation to project images

document.querySelectorAll('#projects img').forEach(image => {

    image.addEventListener('mouseover', () => {

        image.style.transform = 'scale(1.1)';

    });

    image.addEventListener('mouseout', () => {

        image.style.transform = 'scale(1)';

    });

});

// Validate contact form

document.querySelector('#contact form').addEventListener('submit', event => {

    event.preventDefault();

    const name = document.querySelector('#name').value;

    const email = document.querySelector('#email').value;

    const message = document.querySelector('#message').value;

    if (name && email && message) {

        alert('Thank you for your message!');

    } else {

        alert('Please fill out all fields.');

    }

});